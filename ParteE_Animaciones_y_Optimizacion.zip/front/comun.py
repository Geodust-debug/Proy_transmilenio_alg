"""Cosas compartidas por todas las paginas del front (cualquier libreria vale aqui).

El front SOLO llama al motor: ninguna regla del sistema vive aqui.
"""
import csv
import sys
from pathlib import Path

import streamlit as st

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))

from motor import Red  # noqa: E402
from visual import tema  # noqa: E402

_ya_cargada = [False]   # vive mientras el servidor este prendido


@st.cache_resource(show_spinner=False)
def _cargar_red():
    return Red(str(RAIZ / "datos"))


def obtener_red():
    """Una sola Red compartida por todas las paginas (se carga una vez).
    La primera vez se muestra el bus de carga mientras se leen los CSV."""
    if _ya_cargada[0]:
        return _cargar_red()
    with tema.cargando("Cargando la red de TransMilenio"):
        red = _cargar_red()
    _ya_cargada[0] = True
    return red


@st.cache_data
def nombres_estaciones():
    """Todos los nombres de estaciones, en orden alfabetico (para los menus)."""
    with open(RAIZ / "datos" / "estaciones.csv", encoding="utf-8-sig") as f:
        filas = list(csv.reader(f))[1:]
    return sorted(fila[0] for fila in filas if fila)
