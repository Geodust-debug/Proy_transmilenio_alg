# Pasos para subir la Parte E

La Parte E cambia archivos de varias partes del front (para darles el tema nuevo) y tres archivos del
motor de la Parte A. Por eso **se sube de última**, cuando Miguel, Mauricio y Tomás ya hayan subido lo suyo.
Si se sube antes, el push de ellos dejaría sus páginas sin el diseño nuevo.

## 1. Traer lo último
En Git Bash, dentro de la carpeta del proyecto:

```bash
git pull
```

## 2. Copiar los archivos del zip
Descomprime `ParteE_Animaciones_y_Optimizacion.zip` **encima** de la carpeta del proyecto y acepta
reemplazar los archivos. Ojo: trae una carpeta que empieza con punto, `.streamlit`, que en Windows a veces
no se ve; tiene que quedar en la raíz del proyecto, al lado de `README.md`.

El zip **no** trae `integrantes.md`, para no borrar los apellidos que hayan puesto los demás. Abre ese
archivo y agrega al final de la tabla esta fila (con tu nombre):

```text
| Tu nombre | Optimización del motor (R5 en O(P), R10 por conteo, `TablaHash` y merge sort), diseño y animaciones del front | `front/visual/`, `front/app.py`, `front/static/`, `.streamlit/`, `motor/viaje.py`, `motor/fila.py`, `motor/estructuras.py` |
```

Antes de seguir, mira qué cambió en las páginas de los demás:

```bash
git diff --stat
git diff front/pages
```

Si alguien agregó algo propio a su página después de recibir su zip, ese cambio aparece en rojo: cópialo a la
versión nueva antes de hacer commit, para no borrarlo.

## 3. Probar
```bash
python -m pip install -r requirements.txt
python pruebas/revisar_prohibidos.py
python pruebas/probar_integracion.py
python pruebas/probar_parte_e.py
python -m streamlit run front/app.py
```
Las tres pruebas deben terminar en `TODO BIEN` (o `OK`). En la app, recorre las 7 páginas del menú.

## 4. Subir (en varios commits, no en uno solo)
```bash
git add motor/estructuras.py motor/viaje.py motor/fila.py herramientas/medir.py pruebas/probar_parte_e.py
git commit -m "Parte E: optimiza viaje O(P), fila por conteo, TablaHash y merge sort"

git add .streamlit front/static front/visual front/app.py front/comun.py front/inicio.py requirements.txt
git commit -m "Parte E: tema visual, logo, dibujos y escenas de entrada"

git add front/pages
git commit -m "Parte E: páginas con mapa animado del viaje y andén de hora pico"

git add README.md integrantes.md docs
git commit -m "Parte E: README, guía de estudio e imágenes nuevas"

git push
```

Si `git push` dice que hay cambios nuevos en GitHub, haz `git pull` y vuelve a `git push`.
