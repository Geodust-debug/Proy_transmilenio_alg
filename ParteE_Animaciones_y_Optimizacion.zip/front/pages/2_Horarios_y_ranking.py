"""Pagina de la Parte C: proximo bus (R4) y ranking de estaciones (R6).
Solo llama al motor: ninguna regla vive aqui. Diseno: Parte E (front/visual/)."""
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import streamlit as st  # noqa: E402

from comun import RAIZ, obtener_red, nombres_estaciones  # noqa: E402
from visual import tema  # noqa: E402

tema.encabezado("horarios")
COLOR = tema.acento("horarios")
red = obtener_red()
nombres = nombres_estaciones()


@st.cache_data
def rutas_por_estacion():
    """Para el menu: que rutas pasan por cada estacion (solo para armar la lista de opciones)."""
    resultado = {}
    with open(RAIZ / "datos" / "rutas.csv", encoding="utf-8-sig") as f:
        for fila in list(csv.reader(f))[1:]:
            if fila:
                resultado.setdefault(fila[2], []).append(fila[0])
    return resultado


def minutos(hhmm):
    horas, mins = hhmm.split(":")
    return int(horas) * 60 + int(mins)


pestana1, pestana2 = st.tabs(["Próximo bus", "Ranking de estaciones"])

with pestana1:
    tema.html('<p class="tm-nota">¿A qué hora pasa el siguiente bus de una ruta por una estación? (R4)</p>')
    c1, c2, c3 = st.columns(3)
    estacion = c1.selectbox("Estación", nombres, index=None, placeholder="Elige una estación…")
    rutas = sorted(rutas_por_estacion().get(estacion, [])) if estacion else []
    ruta = c2.selectbox("Ruta", rutas, index=None, placeholder="Elige una ruta…", disabled=not rutas)
    hora = c3.time_input("Desde las", value=None, step=300)
    if estacion and ruta and hora:
        pedida = hora.strftime("%H:%M")
        siguiente = red.proximo_bus(estacion, ruta, pedida)
        if red.estado(estacion) == "CERRADA":
            st.warning("La estación está cerrada: no pasan buses por ahí. Puedes reabrirla en Estaciones.")
        elif siguiente is None:
            st.info(f"No hay más buses de la ruta {ruta} en {estacion} después de las {pedida}.")
        else:
            espera = minutos(siguiente) - minutos(pedida)
            if espera == 0:
                detalle = "Está pasando justo a la hora que pediste."
            elif espera == 1:
                detalle = f"Falta <b>1 minuto</b> desde las {pedida}."
            else:
                detalle = f"Faltan <b>{espera} minutos</b> desde las {pedida}."
            tema.tablero(ruta, estacion, siguiente, detalle, COLOR)
    elif estacion and not rutas:
        st.info("Ninguna ruta pasa por esa estación.")

with pestana2:
    tema.html('<p class="tm-nota">Las estaciones abiertas por donde pasan más buses al día (R6). '
              'Las cerradas no aparecen.</p>')
    k = st.slider("¿Cuántas mostrar?", 1, 30, 10)
    tema.ranking(red.ranking(k), COLOR)
