"""Pruebas de la Parte E: optimizaciones del motor y front nuevo.

Uso (desde la raiz del repo):
    python pruebas/probar_parte_e.py

Revisa que las versiones rapidas den EXACTAMENTE lo mismo que una version
lenta y obvia (fuerza bruta), y que todas las paginas de la app abran sin
errores.
"""
import logging
import random
import sys
from pathlib import Path

logging.disable(logging.WARNING)   # sin avisos de Streamlit al probar fuera del servidor

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))
sys.path.insert(0, str(RAIZ / "front"))

from motor import Red, simular_fila  # noqa: E402
from motor import fila as modulo_fila  # noqa: E402
from motor.estructuras import TablaHash, ordenar_mezcla  # noqa: E402
from motor.viaje import _INFINITO  # noqa: E402

DATOS = str(RAIZ / "datos")


def ok(texto):
    print("  ok ·", texto)


# ------------------------------------------------------------ R5 viaje O(P)
def viaje_fuerza_bruta(red, rutas, origen, destino):
    """Costo del mejor viaje (paradas) y numero de tramos, probando TODO."""
    if origen == destino or red.estado(origen) != "ABIERTA" or red.estado(destino) != "ABIERTA":
        return None
    recorridos = [red.recorrido(r) for r in rutas]
    mejor_directo = None
    mejor_transbordo = None
    for a in recorridos:
        for i in range(len(a)):
            if a[i] != origen:
                continue
            for j in range(i + 1, len(a)):
                costo1 = j - i
                if a[j] == destino and (mejor_directo is None or costo1 < mejor_directo):
                    mejor_directo = costo1
                t = a[j]
                if t == destino or red.estado(t) != "ABIERTA":
                    continue
                for b in recorridos:
                    for k in range(len(b)):
                        if b[k] != t:
                            continue
                        for m in range(k + 1, len(b)):
                            if b[m] == destino:
                                total = costo1 + m - k
                                if mejor_transbordo is None or total < mejor_transbordo:
                                    mejor_transbordo = total
    if mejor_directo is not None and (mejor_transbordo is None or mejor_directo <= mejor_transbordo):
        return mejor_directo, 1
    if mejor_transbordo is not None:
        return mejor_transbordo, 2
    return None


def costo_de(red, tramos):
    if tramos is None:
        return None
    total = 0
    for ruta, sube, baja in tramos:
        paradas = red.recorrido(ruta)
        total += paradas.index(baja) - paradas.index(sube)
    return total, len(tramos)


def probar_viaje():
    red = Red(DATOS)
    rutas = red._rutas.nombres()
    nombres = red.rango("A", "ZZZZ")
    azar = random.Random(7)
    assert red.viaje("PORTAL NORTE", "PORTAL SUR") == [
        ("F28-1", "PORTAL NORTE", "AV. CHILE"), ("G22-1", "AV. CHILE", "PORTAL SUR")]
    for vuelta in range(4):
        for _ in range(120):
            o, d = azar.choice(nombres), azar.choice(nombres)
            assert costo_de(red, red.viaje(o, d)) == viaje_fuerza_bruta(red, rutas, o, d), (o, d)
        red.cerrar(azar.choice(nombres))
        ruta = azar.choice(rutas)
        red.agregar_parada(ruta, azar.choice(nombres), red.recorrido(ruta)[0])
    ok("viaje da el mismo costo que la fuerza bruta (con cierres y rutas editadas)")
    v = red._viaje
    limpios = True
    for i in range(len(v._desde_o)):
        if v._desde_o[i] != _INFINITO or v._hasta_d[i] != _INFINITO:
            limpios = False
    assert limpios
    ok("los arreglos de trabajo quedan limpios despues de cada consulta")


# ------------------------------------------------------------ R10 fila
def fila_lenta(llegadas, frecuencia, capacidad):
    """Simulacion obvia segundo a segundo (solo para comparar)."""
    pendientes = sorted(range(len(llegadas)), key=lambda i: (llegadas[i], i))
    salidas = [None] * len(llegadas)
    bus = 1
    while pendientes:
        t = bus * frecuencia
        suben = [i for i in pendientes if llegadas[i] <= t][:capacidad]
        for i in suben:
            salidas[i] = t
        pendientes = [i for i in pendientes if salidas[i] is None]
        bus += 1
    return salidas


def probar_fila():
    azar = random.Random(11)
    for _ in range(300):
        n = azar.randint(1, 70)
        f, c = azar.randint(1, 15), azar.randint(1, 9)
        tope = azar.choice([3, 40, 400, 10 ** 7])
        llegadas = [azar.randint(0, tope) for _ in range(n)]
        if tope < 10 ** 7:   # con rangos enormes la version lenta tardaria mucho
            assert simular_fila(llegadas, f, c) == fila_lenta(llegadas, f, c)
        # las dos formas de ordenar dan el mismo orden
        minimo, maximo = min(llegadas), max(llegadas)
        if maximo - minimo < 5000:
            assert (modulo_fila._orden_por_conteo(llegadas, minimo, maximo - minimo + 1)
                    == modulo_fila._orden_por_mezcla(llegadas))
    ok("simular_fila igual a una simulacion lenta y obvia")
    con_decimales = [0.5, 2.25, 2.25, 31.0, 7.75]
    assert simular_fila(con_decimales, 10, 2) == [10, 10, 20, 40, 20]
    ok("llegadas con decimales usan merge sort y funcionan")


# ------------------------------------------------------------ estructuras
def probar_estructuras():
    azar = random.Random(3)
    t, d = TablaHash(), {}
    for _ in range(30000):
        clave = (azar.choice("ABCDEFG"), azar.randint(0, 900))
        op = azar.random()
        if op < 0.5:
            v = azar.randint(0, 99)
            t.poner(clave, v)
            d[clave] = v
        elif op < 0.8:
            assert t.obtener(clave) == d.get(clave)
            assert t.contiene(clave) == (clave in d)
        else:
            assert t.eliminar(clave) == (d.pop(clave, None) is not None)
        assert len(t) == len(d)
    ok("TablaHash se comporta igual que dict")

    class Par:
        def __init__(self, a, b):
            self.a, self.b = a, b

        def __lt__(self, otro):
            return self.a < otro.a

    for n in [0, 1, 2, 15, 16, 17, 33, 500, 4097]:
        datos = [Par(azar.randint(0, 9), i) for i in range(n)]
        salida = ordenar_mezcla(datos)
        assert [(p.a, p.b) for p in salida] == sorted((p.a, p.b) for p in datos)
        numeros = [azar.random() for _ in range(n)]
        assert ordenar_mezcla(numeros) == sorted(numeros)
        assert ordenar_mezcla(sorted(numeros)) == sorted(numeros)
    ok("ordenar_mezcla ordena y es estable (bloques de 16 + mezcla)")


# ------------------------------------------------------------ front
def probar_front():
    from visual import animaciones, dibujos, tema

    assert dibujos.color_ruta("B13-1")[0] == dibujos.TRONCALES["B"]
    assert dibujos.color_ruta("6-4")[0] == dibujos.TRONCALES["6"]
    for clave in tema.PAGINAS:
        assert tema.PAGINAS[clave][4](tema.acento(clave)).startswith("\n<svg")
    resumen = animaciones.resumen_fila([0, 1, 2, 3, 10], simular_fila([0, 1, 2, 3, 10], 5, 2))
    assert resumen == [[5, 4, 2, 2], [10, 1, 2, 1], [15, 0, 1, 0]]
    ok("dibujos, escenas y resumen de la fila")

    try:
        from streamlit.testing.v1 import AppTest
    except ImportError:
        print("  (streamlit no esta instalado: no se prueban las paginas)")
        return
    paginas = ["inicio.py", "pages/1_Estaciones.py", "pages/2_Horarios_y_ranking.py",
               "pages/3_Operar_red.py", "pages/4_Viaje.py", "pages/5_Hora_pico.py",
               "pages/6_Panel_rendimiento.py"]
    for pagina in paginas:
        app = AppTest.from_file(str(RAIZ / "front" / "app.py"), default_timeout=60)
        app.run()
        if pagina != "inicio.py":
            app.switch_page(pagina)
            app.run()
        assert not app.exception, (pagina, app.exception)
    ok("las 7 paginas abren sin errores")


if __name__ == "__main__":
    print("Parte E")
    probar_estructuras()
    probar_fila()
    probar_viaje()
    probar_front()
    print("TODO BIEN")
